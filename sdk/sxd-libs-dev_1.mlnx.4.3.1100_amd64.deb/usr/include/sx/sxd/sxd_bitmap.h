/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef     __SXD_BITMAP_H__
#define     __SXD_BITMAP_H__

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  Global definitions
 ***********************************************/


/**
 * Get bit # BIT in a bit array called BITMAP which is composed
 * of LEN words, where each word is of WID bits.
 * Assuming: BIT <= LEN x WID.
 */
#define SXD_BITMAP_GET(BITMAP, LEN, WID, BIT) \
    ((BITMAP[((int)(BIT)) / ((int)(WID))]) & (1 << (((int)(BIT)) % ((int)(WID)))))

/**
 * Set bit # BIT in a bit array called BITMAP which is composed
 * of LEN words, where each word is of WID bits.
 * Assuming: BIT <= LEN x WID.
 */
#define SXD_BITMAP_SET(BITMAP, LEN, WID, BIT) \
    (BITMAP[((int)(BIT)) / ((int)(WID))] |= 1 << (((int)(BIT)) % ((int)(WID))))

/**
 * Clear bit # BIT in a bit array called BITMAP which is
 * composed of LEN words, where each word is of WID bits.
 * Assuming: BIT <= LEN x WID.
 */
#define SXD_BITMAP_CLR(BITMAP, LEN, WID, BIT) \
    (BITMAP[((int)(BIT)) / ((int)(WID))] &= ~(1 << ((int)(BIT)) % ((int)(WID))))

/**
 * Bitwise OR (starting from index IND) of two bit arrays called
 * BITMAP1 & BITMAP2 which are both composed of LEN words, where
 * each word is of the same bits width.
 * The result is stored in bit arrays called BITMAP1.
 */
#define SXD_BITMAP_OR(BITMAP1, BITMAP2, LEN, IND)    \
    do {                                             \
        int __index = int(IND), __length = int(LEN); \
        for (; __index < __length; __index++) {      \
            BITMAP1[__index] |= BITMAP2[__index];    \
        }                                            \
    } while (0)

/**
 * Bitwise AND (starting from index IND) of two bit arrays
 * called BITMAP1 & BITMAP2 which are both composed of LEN
 * words, where each word is of the same bits width.
 * The result is stored in bit arrays called BITMAP1.
 */
#define SXD_BITMAP_AND(BITMAP1, BITMAP2, LEN, IND)   \
    do {                                             \
        int __index = int(IND), __length = int(LEN); \
        for (; __index < __length; __index++) {      \
            BITMAP1[__index] &= BITMAP2[__index];    \
        }                                            \
    } while (0)

/**
 * Bitwise XOR (starting from index IND) of two bit arrays
 * called BITMAP1 & BITMAP2 which are both composed of LEN
 * words, where each word is of the same bits width.
 * The result is stored in bit arrays called BITMAP1.
 */
#define SXD_BITMAP_XOR(BITMAP1, BITMAP2, LEN, IND)   \
    do {                                             \
        int __index = int(IND), __length = int(LEN); \
        for (; __index < __length; __index++) {      \
            BITMAP1[__index] ^= BITMAP2[__index];    \
        }                                            \
    } while (0)

/**
 * Bitwise NOT (starting from index IND) of two bit arrays
 * called BITMAP1 & BITMAP2 which are both composed of LEN
 * words, where each word is of the same bits width.
 * The result is stored in bit arrays called BITMAP1.
 */
#define SXD_BITMAP_NOT(BITMAP1, BITMAP2, LEN, IND)   \
    do {                                             \
        int __index = int(IND), __length = int(LEN); \
        for (; __index < __length; __index++) {      \
            BITMAP1[__index] = ~(BITMAP2[__index]);  \
        }                                            \
    } while (0)

#endif  /*	__SXD_BITMAP_H__	*/
