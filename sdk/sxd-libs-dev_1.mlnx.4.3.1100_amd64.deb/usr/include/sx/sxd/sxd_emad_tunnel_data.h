/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_TUNNEL_DATA_H__
#define __SXD_EMAD_TUNNEL_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_swid.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * sxd_emad_tngcr_data_t structure is used to store TNGCR register data.
 */
typedef struct sxd_emad_tngcr_data {
    sxd_emad_common_data_t common;
    struct ku_tngcr_reg   *reg_data;
} sxd_emad_tngcr_data_t;

/**
 * sxd_emad_tncr_data_t structure is used to store TNCR register data.
 */
typedef struct sxd_emad_tncr_data {
    sxd_emad_common_data_t common;
    struct ku_tncr_reg    *reg_data;
} sxd_emad_tncr_data_t;

/**
 * sxd_emad_tnumt_data_t structure is used to store TNUMT register data.
 */
typedef struct sxd_emad_tnumt_data {
    sxd_emad_common_data_t common;
    struct ku_tnumt_reg   *reg_data;
} sxd_emad_tnumt_data_t;

/**
 * sxd_emad_tnqcr_data_t structure is used to store TNQCR register data.
 */
typedef struct sxd_emad_tnqcr_data {
    sxd_emad_common_data_t common;
    struct ku_tnqcr_reg   *reg_data;
} sxd_emad_tnqcr_data_t;

/**
 * sxd_emad_tnqdr_data_t structure is used to store TNQDR register data.
 */
typedef struct sxd_emad_tnqdr_data {
    sxd_emad_common_data_t common;
    struct ku_tnqdr_reg   *reg_data;
} sxd_emad_tnqdr_data_t;

/**
 * sxd_emad_tigcr_data_t structure is used to store TIGCR register data.
 */
typedef struct sxd_emad_tigcr_data {
    sxd_emad_common_data_t common;
    struct ku_tigcr_reg   *reg_data;
} sxd_emad_tigcr_data_t;

/**
 * sxd_emad_tiqdr_data_t structure is used to store TIQDR register data.
 */
typedef struct sxd_emad_tiqdr_data {
    sxd_emad_common_data_t common;
    struct ku_tiqdr_reg   *reg_data;
} sxd_emad_tiqdr_data_t;

/**
 * sxd_emad_tiqcr_data_t structure is used to store TIQCR register data.
 */
typedef struct sxd_emad_tiqcr_data {
    sxd_emad_common_data_t common;
    struct ku_tiqcr_reg   *reg_data;
} sxd_emad_tiqcr_data_t;

/**
 * sxd_emad_tieem_data_t structure is used to store TIEEM register data.
 */
typedef struct sxd_emad_tieem_data {
    sxd_emad_common_data_t common;
    struct ku_tieem_reg   *reg_data;
} sxd_emad_tieem_data_t;

/**
 * sxd_emad_tidem_data_t structure is used to store TIDEM register data.
 */
typedef struct sxd_emad_tidem_data {
    sxd_emad_common_data_t common;
    struct ku_tidem_reg   *reg_data;
} sxd_emad_tidem_data_t;

/**
 * sxd_emad_tneem_data_t structure is used to store TNEEM register data.
 */
typedef struct sxd_emad_tneem_data {
    sxd_emad_common_data_t common;
    struct ku_tneem_reg   *reg_data;
} sxd_emad_tneem_data_t;

/**
 * sxd_emad_tndem_data_t structure is used to store TNDEM register data.
 */
typedef struct sxd_emad_tndem_data {
    sxd_emad_common_data_t common;
    struct ku_tndem_reg   *reg_data;
} sxd_emad_tndem_data_t;

/**
 * sxd_emad_tnifr_data_t structure is used to store TNIFR register data.
 */
typedef struct sxd_emad_tnifr_data {
    sxd_emad_common_data_t common;
    struct ku_tnifr_reg   *reg_data;
} sxd_emad_tnifr_data_t;

#endif /* __SXD_EMAD_TUNNEL_DATA_H__ */
