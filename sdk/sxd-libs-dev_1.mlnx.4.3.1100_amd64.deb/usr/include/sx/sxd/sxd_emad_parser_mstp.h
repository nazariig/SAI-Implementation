/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_MSTP_H__
#define __SXD_EMAD_PARSER_MSTP_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_mstp_data.h>
#include <sx/sxd/sxd_emad_mstp_reg.h>

#ifdef SXD_EMAD_PARSER_MSTP_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/
/************************************************
 *  Local Type definitions
 ***********************************************/

#endif


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_mstp_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                  IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spms(sxd_emad_spms_data_t *spms_data,
                                 sxd_emad_spms_reg_t  *spms_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spms(sxd_emad_spms_data_t *spms_data,
                                   sxd_emad_spms_reg_t  *spms_reg);

#endif /* __SXD_EMAD_PARSER_MSTP_H__ */
