/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_H__
#define __SXD_EMAD_H__

#include <complib/sx_log.h>
#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_data.h>
#include <sx/sxd/sxdev.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_CMD_UNSUPPORTED - unsupported command
 */
sxd_status_t sxd_emad_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                          IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function initializes the SXD EMAD library and should be
 *  called before any use of the it.
 *
 *  @param[in] app_id - Calling application ID
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - Local device initialization failed
 * @return SXD_STATUS_NO_MEMORY - EMAD pool/ transaction queue initialization failed
 */

sxd_status_t sxd_emad_init(uint32_t app_id);

/**
 *  This function deinitializes the SXD EMAD library. Further
 *  use of the library should not be made after it called.
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - de-initialization failed
 */
sxd_status_t sxd_emad_deinit(void);

/**
 *  This function sets EMAD transaction mode
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR -   setting failed
 *
 * @param[in]  enable         - enable/disable transaction mode
 */
sxd_status_t sxd_emad_transaction_mode_set(boolean_t enable);

/* callback to notify on latest EMAD tid that will be sent*/
typedef sxd_status_t (*sxd_emad_notify_latest_tx_tid_cb)(const uint64_t* emad_tid, void *context);

/* callback to notify on latest received emad tid */
typedef sxd_status_t (*sxd_emad_notify_latest_rx_tid_cb)(const uint64_t* emad_tid, void *context);

/**
 *  This function register callback for latest tid notification.
 *
 * @param[in] tx_cb - emad notify latest tx tid.
 * @param[in] rx_cb - emad notify latest rx tid.
 * @param[in] context - context to pass to cb function
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_register_notify_latest_tx_rx_tid_cb(sxd_emad_notify_latest_tx_tid_cb tx_cb,
                                                          sxd_emad_notify_latest_rx_tid_cb rx_cb,
                                                          void                            *context);

#endif /* __SXD_EMAD_H__ */
