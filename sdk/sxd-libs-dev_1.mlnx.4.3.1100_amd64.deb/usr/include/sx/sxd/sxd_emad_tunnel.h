/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_TUNNEL_H__
#define __SXD_EMAD_TUNNEL_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_tunnel_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD TUNNEL MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_tunnel_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                 IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function sets TNGCR register data.
 *
 * @param[in] tngcr_data_arr - TNGCR data array.
 * @param[in] tngcr_data_num - TNGCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tngcr_set(sxd_emad_tngcr_data_t        *tngcr_data_arr,
                                uint32_t                      tngcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TNGCR register data.
 *
 * @param[in] tngcr_data_arr - TNGCR data array.
 * @param[in] tngcr_data_num - TNGCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tngcr_get(sxd_emad_tngcr_data_t        *tngcr_data_arr,
                                uint32_t                      tngcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TNCR register data.
 *
 * @param[in] tncr_data_arr - TNCR data array.
 * @param[in] tncr_data_num - TNCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tncr_set(sxd_emad_tncr_data_t         *tncr_data_arr,
                               uint32_t                      tncr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets TNCR register data.
 *
 * @param[in] tncr_data_arr - TNCR data array.
 * @param[in] tncr_data_num - TNCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tncr_get(sxd_emad_tncr_data_t         *tncr_data_arr,
                               uint32_t                      tncr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets TNUMT register data.
 *
 * @param[in] tnumt_data_arr - TNUMT data array.
 * @param[in] tnumt_data_num - TNUMT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tnumt_set(sxd_emad_tnumt_data_t        *tnumt_data_arr,
                                uint32_t                      tnumt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TNUMT register data.
 *
 * @param[in] tnumt_data_arr - TNUMT data array.
 * @param[in] tnumt_data_num - TNUMT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tnumt_get(sxd_emad_tnumt_data_t        *tnumt_data_arr,
                                uint32_t                      tnumt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TNQCR register data.
 *
 * @param[in] tnqcr_data_arr - TNQCR data array.
 * @param[in] tnqcr_data_num - TNQCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tnqcr_set(sxd_emad_tnqcr_data_t        *tnqcr_data_arr,
                                uint32_t                      tnqcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TNQCR register data.
 *
 * @param[in] tnqcr_data_arr - TNQCR data array.
 * @param[in] tnqcr_data_num - TNQCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tnqcr_get(sxd_emad_tnqcr_data_t        *tnqcr_data_arr,
                                uint32_t                      tnqcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TNQDR register data.
 *
 * @param[in] tnqdr_data_arr - TNQDR data array.
 * @param[in] tnqdr_data_num - TNQDR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tnqdr_set(sxd_emad_tnqdr_data_t        *tnqdr_data_arr,
                                uint32_t                      tnqdr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TNQDR register data.
 *
 * @param[in] tnqdr_data_arr - TNQDR data array.
 * @param[in] tnqdr_data_num - TNQDR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tnqdr_get(sxd_emad_tnqdr_data_t        *tnqdr_data_arr,
                                uint32_t                      tnqdr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TIGCR register data.
 *
 * @param[in] tigcr_data_arr - TIGCR data array.
 * @param[in] tigcr_data_num - TIGCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tigcr_set(sxd_emad_tigcr_data_t        *tigcr_data_arr,
                                uint32_t                      tigcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TIGCR register data.
 *
 * @param[in] tigcr_data_arr - TIGCR data array.
 * @param[in] tigcr_data_num - TIGCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tigcr_get(sxd_emad_tigcr_data_t        *tigcr_data_arr,
                                uint32_t                      tigcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TIQDR register data.
 *
 * @param[in] tiqdr_data_arr - TIQDR data array.
 * @param[in] tiqdr_data_num - TIQDR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tiqdr_set(sxd_emad_tiqdr_data_t        *tiqdr_data_arr,
                                uint32_t                      tiqdr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TIQDR register data.
 *
 * @param[in] tiqdr_data_arr - TIQDR data array.
 * @param[in] tiqdr_data_num - TIQDR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tiqdr_get(sxd_emad_tiqdr_data_t        *tiqdr_data_arr,
                                uint32_t                      tiqdr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TIQCR register data.
 *
 * @param[in] tiqcr_data_arr - TIQCR data array.
 * @param[in] tiqcr_data_num - TIQCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tiqcr_set(sxd_emad_tiqcr_data_t        *tiqcr_data_arr,
                                uint32_t                      tiqcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TIQCR register data.
 *
 * @param[in] tiqcr_data_arr - TIQCR data array.
 * @param[in] tiqcr_data_num - TIQCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tiqcr_get(sxd_emad_tiqcr_data_t        *tiqcr_data_arr,
                                uint32_t                      tiqcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TIEEM register data.
 *
 * @param[in] tieem_data_arr - TIEEM data array.
 * @param[in] tieem_data_num - TIEEM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tieem_set(sxd_emad_tieem_data_t        *tieem_data_arr,
                                uint32_t                      tieem_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TIEEM register data.
 *
 * @param[in] tieem_data_arr - TIEEM data array.
 * @param[in] tieem_data_num - TIEEM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tieem_get(sxd_emad_tieem_data_t        *tieem_data_arr,
                                uint32_t                      tieem_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TIDEM register data.
 *
 * @param[in] tidem_data_arr - TIDEM data array.
 * @param[in] tidem_data_num - TIDEM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tidem_set(sxd_emad_tidem_data_t        *tidem_data_arr,
                                uint32_t                      tidem_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TIDEM register data.
 *
 * @param[in] tidem_data_arr - TIDEM data array.
 * @param[in] tidem_data_num - TIDEM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tidem_get(sxd_emad_tidem_data_t        *tidem_data_arr,
                                uint32_t                      tidem_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TNEEM register data.
 *
 * @param[in] tneem_data_arr - TNEEM data array.
 * @param[in] tneem_data_num - TNEEM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tneem_set(sxd_emad_tneem_data_t        *tneem_data_arr,
                                uint32_t                      tneem_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TNEEM register data.
 *
 * @param[in] tneem_data_arr - TNEEM data array.
 * @param[in] tneem_data_num - TNEEM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tneem_get(sxd_emad_tneem_data_t        *tneem_data_arr,
                                uint32_t                      tneem_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TNDEM register data.
 *
 * @param[in] tndem_data_arr - TNDEM data array.
 * @param[in] tndem_data_num - TNDEM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tndem_set(sxd_emad_tndem_data_t        *tndem_data_arr,
                                uint32_t                      tndem_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TNDEM register data.
 *
 * @param[in] tndem_data_arr - TNDEM data array.
 * @param[in] tndem_data_num - TNDEM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tndem_get(sxd_emad_tndem_data_t        *tndem_data_arr,
                                uint32_t                      tndem_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets TNIFR register data.
 *
 * @param[in] tnifr_data_arr - TNIFR data array.
 * @param[in] tnifr_data_num - TNIFR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tnifr_set(sxd_emad_tnifr_data_t        *tnifr_data_arr,
                                uint32_t                      tnifr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets TNIFR register data.
 *
 * @param[in] tnifr_data_arr - TNIFR data array.
 * @param[in] tnifr_data_num - TNIFR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_tnifr_get(sxd_emad_tnifr_data_t        *tnifr_data_arr,
                                uint32_t                      tnifr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

#endif /* __SXD_EMAD_TUNNEL_H__ */
