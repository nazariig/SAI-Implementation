/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_FCF_REG_H__
#define __SXD_EMAD_FCF_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_fgcr_reg_t structure is used to store FGCR register layout.
 */
typedef struct sxd_emad_fgcr_reg {
    uint8_t fcf_en;
    uint8_t reserved1[5];
    net16_t max_fcf_instances;
    net16_t reserved2;
    net16_t max_ve_ports;
    uint8_t reserved3[6];
    uint8_t fcf_mac[6];
    uint8_t reserved4[8];
} PACK_SUFFIX sxd_emad_fgcr_reg_t;

/**
 * sxd_emad_fipl_reg_t structure is used to store FIPL register layout.
 */
typedef struct sxd_emad_fipl_reg {
    uint8_t ipl[32];
    uint8_t ipl_mask[32];
} PACK_SUFFIX sxd_emad_fipl_reg_t;

/**
 * sxd_emad_fvet_reg_t structure is used to store FVET register layout.
 */
typedef struct sxd_emad_fvet_reg {
    uint8_t valid;
    uint8_t reserved1;
    net16_t ve_port_index;
    uint8_t reserved2[6];
    uint8_t mac[6];
} PACK_SUFFIX sxd_emad_fvet_reg_t;

/**
 * sxd_emad_fitr_reg_t structure is used to store FITR register layout.
 */
typedef struct sxd_emad_fitr_reg {
    uint8_t valid;
    net16_t reserved1;
    uint8_t instance_id;
    uint8_t reserved2[5];
    uint8_t fc_map[3];
    net16_t reserved3;
    net16_t prio_vid;
    net32_t reserved4;
} PACK_SUFFIX sxd_emad_fitr_reg_t;

/**
 * sxd_emad_ffar_reg_t structure is used to store FFAR register layout.
 */
typedef struct sxd_emad_ffar_reg {
    uint8_t op;
    uint8_t reserved1[5];
    net16_t region_size;
} PACK_SUFFIX sxd_emad_ffar_reg_t;

/**
 * sxd_emad_fftr_reg_t structure is used to store FFTR register layout.
 */
typedef struct sxd_emad_fftr_reg {
    uint8_t valid;
    uint8_t op;
    net16_t offset;
    uint8_t reserved1;
    uint8_t fcf_instance;
    uint8_t reserved2[11];
    uint8_t did[3];
    uint8_t reserved3;
    uint8_t did_mask[3];
    uint8_t reserved4;
    uint8_t sid[3];
    uint8_t reserved5;
    uint8_t sid_mask[3];
    uint8_t reserved6[28];
    uint8_t ept;
    uint8_t reserved7[9];
    net16_t ve_port_index;
} PACK_SUFFIX sxd_emad_fftr_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_FCF_REG_H__ */
