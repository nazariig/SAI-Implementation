/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_MPLS_H__
#define __SXD_EMAD_MPLS_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_mpls_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function Sets the MPGCR Switch Descriptor fields.
 *
 * @param[in,out]   mpgcr_data_arr - MPGCR EMAD array
 * @param[in]       mpgcr_data_num - Number of MPGCR EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mpgcr_set(sxd_emad_mpgcr_data_t        *mpgcr_data_arr,
                                uint32_t                      mpgcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 * This function Retrieves the MPGCR Switch Descriptor fields.
 *
 * @param[in,out]   mpgcr_data_arr - MPGCR EMAD array
 * @param[in]       mpgcr_data_num - Number of MPGCR EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mpgcr_get(sxd_emad_mpgcr_data_t        *mpgcr_data_arr,
                                uint32_t                      mpgcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 * This function Sets the MPILM Switch Descriptor fields.
 *
 * @param[in,out]   mpilm_data_arr - MPILM EMAD array
 * @param[in]       mpilm_data_num - Number of MPILM EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mpilm_set(sxd_emad_mpilm_data_t        *mpilm_data_arr,
                                uint32_t                      mpilm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 * This function Retrieves the MPILM Switch Descriptor fields.
 *
 * @param[in,out]   mpilm_data_arr - MPILM EMAD array
 * @param[in]       mpilm_data_num - Number of MPILM EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mpilm_get(sxd_emad_mpilm_data_t        *mpilm_data_arr,
                                uint32_t                      mpilm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 * This function Sets the MPNHLFE Switch Descriptor fields.
 *
 * @param[in,out]   mpnhlfe_data_arr - MPNHLFE EMAD array
 * @param[in]       mpnhlfe_data_num - Number of MPNHLFE EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mpnhlfe_set(sxd_emad_mpnhlfe_data_t      *mpnhlfe_data_arr,
                                  uint32_t                      mpnhlfe_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

/**
 * This function Retrieves the MPNHLFE Switch Descriptor fields.
 *
 * @param[in,out]   mpnhlfe_data_arr - MPNHLFE EMAD array
 * @param[in]       mpnhlfe_data_num - Number of MPNHLFE EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mpnhlfe_get(sxd_emad_mpnhlfe_data_t      *mpnhlfe_data_arr,
                                  uint32_t                      mpnhlfe_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

#endif /* __SXD_EMAD_MPLS_H__ */
