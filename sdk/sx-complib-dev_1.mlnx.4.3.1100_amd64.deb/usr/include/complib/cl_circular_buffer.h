/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __CL_CIRCULAR_BUFFER_H_
#define __CL_CIRCULAR_BUFFER_H_

/**
 * This library implements the circular buffer data type and all operations defined on it
 */

#include <complib/cl_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

typedef struct circ_buff_data {
    uint32_t  read_index;
    uint32_t  write_index;
    uint32_t  obj_size;
    uint32_t  max_num_entries;
    boolean_t full;
    char      buffer[0];
} circ_buff_data_t;

typedef circ_buff_data_t* sx_circ_buff_t;
/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Allocates and initializes a new Circular Buffer.
 * When this function returns, there are no entries to read from the buffer.
 * @param[in] obj_size - Requested size of each object in the buffer.
 * @param[in] max_num_entries - Requested number of entries in the buffer.
 * @param[out] buff_p - Returns a newly allocated circular buffer.
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise.
 */
cl_status_t cl_circ_buff_allocate(uint32_t obj_size, uint32_t max_num_entries, sx_circ_buff_t *buff_p);

/**
 * Frees a previously allocated circular buffer
 * @param[in] buffer - A circular buffer to manipulate
 * @param[in] force - Forced deinit
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise.
 */
cl_status_t cl_circ_buff_free(sx_circ_buff_t buffer, boolean_t force);

/**
 * Resets a circular buffer
 * @param[in] buffer - A circular buffer to manipulate
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise.
 */
void cl_circ_buff_reset(sx_circ_buff_t buffer);

/**
 * Writes a new entry to a circular buffer
 * @param[in] buffer - A circular buffer to manipulate
 * @param[in] new_entry_p - A pointer to data of the new entry
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise.
 */
cl_status_t cl_circ_buff_write(sx_circ_buff_t buffer, void *new_entry_p);

void cl_circ_buff_overwrite(sx_circ_buff_t buffer, void *new_entry_p);

/**
 * Reads and returns data from a circular buffer.
 * The same data will not be available to be read again.
 * @param[in] buffer - A circular buffer to manipulate
 * @param[out] entry_p - pointer to where the data will be copied to.
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise.
 */
cl_status_t cl_circ_buff_read(sx_circ_buff_t bufffer, void *entry_p);

/**
 * Reads and returns data from a circular buffer.
 * The same data will be available to be read again.
 * @param[in] buffer - A circular buffer to manipulate
 * @param[out] entry_p - pointer to where the data will be copied to.
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise.
 */
cl_status_t cl_circ_buff_peek(sx_circ_buff_t buffer, void *entry_p);

boolean_t cl_circ_buff_empty(sx_circ_buff_t buffer);

#endif /* __CL_CIRCULAR_BUFFER_H_ */
