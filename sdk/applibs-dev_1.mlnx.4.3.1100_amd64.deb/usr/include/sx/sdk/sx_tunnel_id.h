/*
 *  Copyright (C) 2014-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */
#ifndef __SX_TUNNEL_ID_H__
#define __SX_TUNNEL_ID_H__

/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * Tunnel ID.
 *
 * t - Tunnel Type - 8 bit
 * d - Tunnel Direction - 2 bit
 * i - Tunnel Identifier - 22 bit
 *
 * 32       24  22                0
 * +--------+---+-----------------+
 * |    t   | d |        i        |
 * +--------+---+-----------------+
 *
 */
typedef uint32_t sx_tunnel_id_t;

/**
 * Tunnel VNI Identifier
 */
typedef uint32_t sx_tunnel_vni_t;

/**
 * Tunnel GRE Key
 */
typedef uint32_t sx_tunnel_gre_key_t;

#define SX_TUNNEL_ID_INVALID ((sx_tunnel_id_t)0)
#define SX_TUNNEL_NUM_MAX    rm_resource_global.tunnel_ipinip_num_max + rm_resource_global.tunnel_nve_num_max

#define FOREACH_TUNNEL_TYPE(F)                                                                                                \
    F(SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4 = 0 /**< IPinIP Point 2 Point connected using IPv4 Over IPv4 */,                 \
      "IPinIP P2P IPv4 in IPv4")                                                                                              \
    F(SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE /**< IPinIP Point 2 Point over IPv4 with GRE */,                                  \
      "IPinIP P2P IPv4 in GRE")                                                                                               \
    F(SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4 /**< IPinIP Point 2 Point connected using IPv6 Over IPv4 */,                     \
      "IPinIP P2P IPv6 in IPv4")                                                                                              \
    F(                                                                                                                        \
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE /**< IPinIP Point 2 Point connected using IPv6 Over IPv4 with GRE */, \
        "IPinIP P2P IPv6 in IPv4 with GRE")                                                                                   \
    F(SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6 /**< IPinIP Point 2 Point connected using IPv4 Over IPv6 */,                     \
      "IPinIP P2P IPv4 in IPv6")                                                                                              \
    F(                                                                                                                        \
        SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE /**< IPinIP Point 2 Point connected using IPv4 Over IPv6 with GRE */, \
        "IPinIP P2P IPv4 in IPv6 with GRE")                                                                                   \
    F(SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6 /**< IPinIP Point 2 Point connected using IPv6 Over IPv6 */,                     \
      "IPinIP P2P IPv6 in IPv6")                                                                                              \
    F(SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE /**< IPinIP Point 2 Point connected using IPv6 Over IPv6 with GRE*/,              \
      "IPinIP P2P IPv6 in IPv6 with GRE")                                                                                     \
    F(SX_TUNNEL_TYPE_NVE_VXLAN /**< NVE VxLan */, "NVE VXLAN")                                                                \
    F(SX_TUNNEL_TYPE_NVE_VXLAN_GPE /**< NVE VxLan-GPE */, "NVE VXLAN GPE")                                                    \
    F(SX_TUNNEL_TYPE_NVE_GENEVE /**< NVE Geneve */, "NVE GENEVE")                                                             \
    F(SX_TUNNEL_TYPE_NVE_NVGRE /**< NVE Nvgre */, "NVE NVGRE")                                                                \
    F(SX_TUNNEL_TYPE_NVE_VXLAN_IPV6 /**< NVE IPv6 VxLan */, "NVE VXLAN IPv6")                                                 \
    F(SX_TUNNEL_TYPE_IPINIP_MIN = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4, "")                                                 \
    F(SX_TUNNEL_TYPE_IPINIP_MAX = SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE, "")                                                  \
    F(SX_TUNNEL_TYPE_NVE_MIN = SX_TUNNEL_TYPE_NVE_VXLAN, "")                                                                  \
    F(SX_TUNNEL_TYPE_NVE_MAX = SX_TUNNEL_TYPE_NVE_VXLAN_IPV6, "")                                                             \
    F(SX_TUNNEL_TYPE_MIN = SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4, "")                                                        \
    F(SX_TUNNEL_TYPE_MAX = SX_TUNNEL_TYPE_NVE_VXLAN_IPV6, "")

typedef enum sx_tunnel_type {
    FOREACH_TUNNEL_TYPE(SX_GENERATE_ENUM)
} sx_tunnel_type_e;

#define FOREACH_TUNNEL_DIRECTION(F)                                                                                                       \
    F(SX_TUNNEL_DIRECTION_NONE = 0, "None")                                                                                               \
    F(SX_TUNNEL_DIRECTION_ENCAP = 1 /**< Tunnel Supports Encapsulation only */, "Encap")                                                  \
    F(SX_TUNNEL_DIRECTION_DECAP = 2 /**< Tunnel Supports Decapsulation only */, "Decap")                                                  \
    F(                                                                                                                                    \
        SX_TUNNEL_DIRECTION_SYMMETRIC = (SX_TUNNEL_DIRECTION_ENCAP | SX_TUNNEL_DIRECTION_DECAP) /**< Tunnel supports both directions. */, \
        "Symmetric")                                                                                                                      \
    F(SX_TUNNEL_DIRECTION_MIN = SX_TUNNEL_DIRECTION_ENCAP, "")                                                                            \
    F(SX_TUNNEL_DIRECTION_MAX = SX_TUNNEL_DIRECTION_SYMMETRIC, "")

/**
 * Tunnel Direction
 */
typedef enum sx_tunnel_direction {
    FOREACH_TUNNEL_DIRECTION(SX_GENERATE_ENUM)
} sx_tunnel_direction_e;

#define FOREACH_TUNNEL_UNDERLAY_DOMAIN_TYPE(F)                                                                         \
    F(SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID = 0 /**< Tunnel use underlay vrid  Supported devices: Spectrum, Spectrum2*/, \
      "VRID")                                                                                                          \
    F(SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF = 1 /**< Tunnel use underlay rif   Supported devices: Spectrum2*/, "RIF")     \
    F(SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_MIN = SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID, "")                                    \
    F(SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_MAX = SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF, "")

/**
 * Tunnel Underlay Domain Type
 */
typedef enum sx_tunnel_underlay_domain_type {
    FOREACH_TUNNEL_UNDERLAY_DOMAIN_TYPE(SX_GENERATE_ENUM)
} sx_tunnel_underlay_domain_type_e;

/**
 * General Helpers for tunnels
 */
#define SX_TUNNEL_TYPE_ID_OFFSET   (24)
#define SX_TUNNEL_DIRECTION_OFFSET (22)
#define SX_TUNNEL_IDENTIFIER_MASK  (0x3fffff)
#define SX_TUNNEL_TYPE_ID_MASK     (0xff << SX_TUNNEL_TYPE_ID_OFFSET)
#define SX_TUNNEL_DIRECTION_MASK   (0x3 << SX_TUNNEL_DIRECTION_OFFSET)
#define SX_TUNNEL_VNI_VALUE_MIN    (0)
#define SX_TUNNEL_VNI_VALUE_MAX    (0xfffffe)
#define SX_TUNNEL_IDENTIFIER_CLR(id) \
    ((id) &= ~SX_TUNNEL_IDENTIFIER_MASK)
#define SX_TUNNEL_TYPE_ID_CLR(id) \
    ((id) &= ~SX_TUNNEL_TYPE_ID_MASK)
#define SX_TUNNEL_DIRECTION_CLR(id) \
    ((id) &= ~SX_TUNNEL_DIRECTION_MASK)
#define SX_TUNNEL_IDENTIFIER_SET(id, identifier) \
    ((id & ~SX_TUNNEL_IDENTIFIER_MASK) | (identifier))
#define SX_TUNNEL_TYPE_ID_SET(id, type) \
    ((id & ~SX_TUNNEL_TYPE_ID_MASK) | ((type) << SX_TUNNEL_TYPE_ID_OFFSET))
#define SX_TUNNEL_DIRECTION_SET(id, type) \
    ((id & ~SX_TUNNEL_DIRECTION_MASK) | ((type) << SX_TUNNEL_DIRECTION_OFFSET))
#define SX_TUNNEL_IDENTIFIER_GET(tunnel_id) \
    ((tunnel_id) & SX_TUNNEL_IDENTIFIER_MASK)
#define SX_TUNNEL_TYPE_ID_GET(tunnel_id) \
    (((tunnel_id) & SX_TUNNEL_TYPE_ID_MASK) >> SX_TUNNEL_TYPE_ID_OFFSET)
#define SX_TUNNEL_DIRECTION_GET(tunnel_id) \
    (((tunnel_id) & SX_TUNNEL_DIRECTION_MASK) >> SX_TUNNEL_DIRECTION_OFFSET)
#define SX_TUNNEL_TYPE_CHECK_RANGE(tunnel_type) \
    SX_CHECK_MAX(tunnel_type, SX_TUNNEL_TYPE_MAX)
#define SX_TUNNEL_DIRECTION_CHECK_RANGE(tunnel_direction) \
    SX_CHECK_RANGE(SX_TUNNEL_DIRECTION_MIN, tunnel_direction, SX_TUNNEL_DIRECTION_MAX)
#define SX_TUNNEL_TYPE_ID_CHECK(tunnel_id, tunnel_type) \
    (SX_TUNNEL_TYPE_ID_GET(tunnel_id) == tunnel_type)
#define SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id) \
    (SX_TUNNEL_DIRECTION_GET(tunnel_id) & SX_TUNNEL_DIRECTION_ENCAP)
#define SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id) \
    (SX_TUNNEL_DIRECTION_GET(tunnel_id) & SX_TUNNEL_DIRECTION_DECAP)
#define SX_TUNNEL_TYPE_ID_PROTO_CHECK(tunnel_id, range_min, range_max) \
    SX_CHECK_RANGE((range_min), SX_TUNNEL_TYPE_ID_GET(tunnel_id), (range_max))
#define SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)                                  \
    (SX_CHECK_MAX(SX_TUNNEL_IDENTIFIER_GET(tunnel_id), SX_TUNNEL_NUM_MAX) && \
     SX_TUNNEL_TYPE_CHECK_RANGE(SX_TUNNEL_TYPE_ID_GET(tunnel_id)) &&         \
     SX_TUNNEL_DIRECTION_CHECK_RANGE(SX_TUNNEL_DIRECTION_GET(tunnel_id)))
#define SX_TUNNEL_VNI_RANGE_CHECK(vni) \
    (SX_CHECK_MAX((vni), SX_TUNNEL_VNI_VALUE_MAX))

/**
 * Type specific helpers.
 */
#define SX_TUNNEL_TYPE_IPINIP_CHECK(tunnel_id) \
    SX_CHECK_MAX(SX_TUNNEL_TYPE_ID_GET(tunnel_id), SX_TUNNEL_TYPE_IPINIP_MAX)
#define SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id)               \
    SX_TUNNEL_TYPE_ID_PROTO_CHECK(tunnel_id,              \
                                  SX_TUNNEL_TYPE_NVE_MIN, \
                                  SX_TUNNEL_TYPE_NVE_MAX)
#define SX_TUNNEL_ID_IP_CONSISTENCY_CHECK(tunnel_id, ip_version) \
    SX_TUNNEL_TYPE_IP_CONSISTENCY_CHECK(SX_TUNNEL_TYPE_ID_GET((tunnel_id)), (ip_version))
#define SX_TUNNEL_TYPE_IP_CONSISTENCY_CHECK(tunnel_type, ip_version) \
    ((((ip_version) == SX_IP_VERSION_IPV6)                           \
      && ((tunnel_type) == SX_TUNNEL_TYPE_NVE_VXLAN_IPV6)) ||        \
     (((ip_version) == SX_IP_VERSION_IPV4)                           \
      && (SX_CHECK_MAX((tunnel_type), SX_TUNNEL_TYPE_NVE_NVGRE))))


#endif /* __SX_TUNNEL_ID_H__ */
