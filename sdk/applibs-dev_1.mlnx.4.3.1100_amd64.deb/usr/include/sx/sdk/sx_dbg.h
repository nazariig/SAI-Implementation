/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_DBG_H__
#define __SX_DBG_H__

#include <stdlib.h>
#include <stdint.h>

/************************************************
 *  Type definitions
 ***********************************************/

/* TODO - currently - this API are using a workaround in order to solve compilation errors
 * when using SWIG to generate python modules.
 * We don't use the types in atcam_types.h but rather we use native types defined by the standard.
 * Obviously, this should be changes as soon as possible.
 */
typedef uint32_t sx_atcam_region_id_t;
typedef uint8_t sx_atcam_erp_id_t;

typedef enum sx_dbg_atcam_cmd_type {
    SX_DBG_ATCAM_CMD_ERPS_SAMPLING_SET_E,
    SX_DBG_ATCAM_CMD_ERPS_COUNTERS_SAMPLE_E,
    SX_DBG_ATCAM_CMD_REGION_ERPS_GET_E,
    SX_DBG_ATCAM_CMD_REORDER_REGION_ERPS_E,
    SX_DBG_ATCAM_CMD_REGION_COUNTERS_SET_E,
    SX_DBG_ATCAM_CMD_REGION_COUNTERS_READ_E,
    SX_DBG_ATCAM_CMD_ERP_COUNTERS_SET_E,
    SX_DBG_ATCAM_CMD_ERP_COUNTERS_READ_E,
} sx_dbg_atcam_cmd_type_e;

typedef struct sx_dbg_atcam_erps_sampling_set {
    boolean_t enable_sampling;
} sx_dbg_atcam_erps_sampling_set_t;

typedef struct sx_dbg_atcam_region_erps_get {
    uint32_t region_id;
    uint8_t  erps_ids[16];
} sx_dbg_atcam_region_erps_get_t;

typedef struct sx_dbg_atcam_reorder_region_erps {
    uint32_t  region_id;
    uint8_t   erps_ids[16];
    boolean_t completed;
} sx_dbg_atcam_reorder_region_erps_t;

typedef struct sx_dbg_atcam_region_counters_set {
    uint32_t region_id;                 /* The region ids on which to apply the region counters */
    uint32_t region_id_bitmask;         /* 0 - compare region_id relevant bit, 1 - ignore region_id relevant bit */
} sx_dbg_atcam_region_counters_set_t;

typedef struct sx_dbg_atcam_region_counters_read {
    boolean_t clear;                  /* Whether to clear the counters after the read */
    uint64_t  lookup_count;           /* The number of times the regions were accessed */
    uint64_t  full_lookup_count;      /* The number of times the regions performed a full lookup (Not a cache match) */
} sx_dbg_atcam_region_counters_read_t;

typedef struct sx_dbg_atcam_erp_counters_set {
    uint32_t  region_id;             /* The region ids on which to apply the region counters */
    uint32_t  region_id_bitmask;     /* 0 bit - compare region_id relevant bit, 1 bit - ignore region_id relevant bit */
    uint16_t  erp_bitmask;           /* Each 1 bit represent an ERP we're interested in. If region_id_bitmask !=0 all erps are counted */
    boolean_t ctcam;                 /* Count CTCAM lookups . If region_id_bitmask !=0 CTCAM is always counted */
} sx_dbg_atcam_erp_counters_set_t;

typedef struct sx_dbg_atcam_erp_counters_read {
    boolean_t clear;                   /* Whether to clear the counters after the read */
    uint64_t  initial_count;           /* ERPs + CTCAM access count (erp vector) before any filtering */
    uint64_t  post_bf_count;           /* ERPs active after BF. Doesn't increment on CTCAM */
    uint64_t  lookup_count;            /* ERPs + CTCAM lookups after BF and Prune */
    uint64_t  any_match_count;         /* ERPs + CTCAM had any match (may not be the final match) */
    uint64_t  final_match_count;       /* ERPs or CTCAM had a final match */
} sx_dbg_atcam_erp_counters_read_t;

typedef struct sx_dbg_atcam_cmd_info {
    sx_dbg_atcam_cmd_type_e type;
    union {
        sx_dbg_atcam_erps_sampling_set_t    erps_sample_set;
        sx_dbg_atcam_region_erps_get_t      region_erps_get;
        sx_dbg_atcam_reorder_region_erps_t  reorder_region_erps;
        sx_dbg_atcam_region_counters_set_t  region_counters_set;
        sx_dbg_atcam_region_counters_read_t region_counters_read;
        sx_dbg_atcam_erp_counters_set_t     erp_counters_set;
        sx_dbg_atcam_erp_counters_read_t    erp_counters_read;
    } data;
} sx_dbg_atcam_cmd_info_t;


#endif /* __SX_DBG_H__ */
