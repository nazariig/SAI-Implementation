/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef SX_COS_REDECN_H_
#define SX_COS_REDECN_H_


#include <resource_manager/resource_manager.h>
#include <complib/cl_types.h>
/************************************************
 *  Type definitions
 ***********************************************/
/**
 * sx_cos_redecn_profile_t is used to store redecn profiles
 */
typedef uint32_t sx_cos_redecn_profile_t;


/**
 * structure to configure global parameters
 */
typedef struct sx_cos_redecn_global {
    boolean_t source_congestion_detection_only;  /**< detect but don't mark */
    uint32_t  weight;
    /* weight 0-1000 (where 1000 is 100%)
     *  note: aqs is calculation as follows:
     *  aqs = ((current_queue_size)*weight) + ((previous_aqs)*(1-weight))).*/
} sx_cos_redecn_global_t;

/**
 * The sx_cos_redecn_tc_mode_e enum defines the traffic class mode for REDECN
 */
typedef enum sx_cos_redecn_mode_e {
    SX_COS_REDECN_MODE_ABSOLUTE = 0,
    SX_COS_REDECN_MODE_RELATIVE = 1,
    SX_COS_REDECN_MODE_MAX = SX_COS_REDECN_MODE_RELATIVE
} sx_cos_redecn_mode_e;

/**
 * The sx_cos_redecn_absolute_mode_attributes_t struct is used
 * with the absolute_mode member of sx_cos_redecn_profile_attributes
 */
typedef struct sx_cos_redecn_absolute_mode_attributes {
    uint32_t min;              /**< Minimum Average Queue Size of the profile, in cells. Valid inputs are 0..buffer_size
                                **<  value must be greater than (1/weight) [cells]    */
    uint32_t max;              /**< Maximum Average Queue Size of the profile, in cells. Valid inputs are 0..buffer_size */
} sx_cos_redecn_absolute_mode_attributes_t;

/**
 * The sx_cos_redecn_relative_mode_attributes_t struct is used
 * with the relative_mode member of sx_cos_redecn_profile_attributes
 */
typedef struct sx_cos_redecn_relative_mode_attributes {
    uint8_t min;   /** Percentage from the number of cells dedicated to the quota of port,TC according the configured alpha. accuracy is 1%. */
    uint8_t max;   /** Percentage from the number of cells dedicated to the quota of port,TC according the configured alpha. accuracy is 1%. */
} sx_cos_redecn_relative_mode_attributes_t;
/**
 * sx_cos_redecn_profile_tc_config_params is used to configure a single
 * traffic class profile.
 * @see sx_api_cos_redecn_profile_tc_config_set
 */
typedef struct sx_cos_redecn_profile_attributes {
    sx_cos_redecn_mode_e mode;                          /** tc mode for this profile */
    uint8_t              high_drop_percent;             /** Percentage of dropping/ECN marking for Maximum Average Queue Size */
    union {
        sx_cos_redecn_absolute_mode_attributes_t absolute_mode;    /** use this member for tc_mode = SX_COS_REDECN_MODE_RELATIVE */
        sx_cos_redecn_relative_mode_attributes_t relative_mode;   /** use this member for tc_mode = SX_COS_REDECN_MODE_ABSOLUTE */
    } values;
} sx_cos_redecn_profile_attributes_t;


/**
 * sx_cos_redecn_flow_type_e represents the various colors of data flows
 */
typedef enum sx_cos_redecn_flow_type_e {
    SX_COS_REDECN_FLOW_TYPE_TCP_GREEN,
    SX_COS_REDECN_FLOW_TYPE_TCP_YELLOW,
    SX_COS_REDECN_FLOW_TYPE_TCP_RED,
    SX_COS_REDECN_FLOW_TYPE_NON_TCP_GREEN,
    SX_COS_REDECN_FLOW_TYPE_NON_TCP_YELLOW,
    SX_COS_REDECN_FLOW_TYPE_NON_TCP_RED,
    SX_COS_REDECN_FLOW_TYPE_MAX = SX_COS_REDECN_FLOW_TYPE_NON_TCP_RED
} sx_cos_redecn_flow_type_e;


/**
 * sx_cos_redecn_enable_params_t is used to enable red/ecn mode for a specific port
 */
typedef struct sx_cos_redecn_enable_params {
    sx_cos_redecn_mode_e mode;                                                  /** tc mode for this profile				 */
    boolean_t            red_enabled;                                           /** red state                                */
    boolean_t            ecn_enabled;                                           /** ecn state                                */
} sx_cos_redecn_enable_params_t;

/**
 * sx_cos_redecn_bind_params_t is used to bind a profile to traffic class
 */
typedef struct sx_cos_redecn_bind_params {
    sx_cos_redecn_profile_t tc_profile;
} sx_cos_redecn_bind_params_t;

/**
 * this structure is used to configure rate based ecn
 */
typedef struct sx_cos_redecn_rate_based_params {
    uint32_t bandwith_threshold;                        /** threshold to set between 0 and port bandwidth.
                                                         *   Units of 1000bps, bps only
                                                         *   Granularity is 200mbps
                                                         *   Error is up to 3% from configuration (for example: at 100Gbps,
                                                         *   rate is configured to 200mbps, actual rate may be 206mbps) */
    uint8_t marking_percent;                            /** Marking percentage when ports rate is above the threshold of the port rate limiter.
                                                         *    Percentage of dropping/ECN marking for Maximum Average Queue Size */
} sx_cos_redecn_rate_based_params_t;

/**
 * This structure is contains counters for red/ecn
 */
typedef struct sx_cos_redecn_port_counters {
    uint64_t tc_red_dropped_packets[RM_API_COS_TRAFFIC_CLASS_NUM];  /** traffic class counters */
    uint64_t ecn_marked_packets;                                    /** ecn counter			   */
} sx_cos_redecn_port_counters_t;


#endif /* ifndef SX_COS_REDECN_H_ */
