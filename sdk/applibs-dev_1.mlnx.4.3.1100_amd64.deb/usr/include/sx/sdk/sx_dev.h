/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_DEV_H__
#define __SX_DEV_H__

#include <sx/sdk/sx_status.h>
#include <sx/sdk/sx_fdb.h>
#include <sx/sdk/sx_access_cmd.h>
#include <sx/sxd/sxd_dev.h>
#include <sx/sxd/sxdev.h>


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sx_dev_id_t
 * Primitive type - Used to note device ID.
 */
typedef sxd_dev_id_t sx_dev_id_t;
typedef sx_dev_id_t sx_device_id_t;

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define SX_DEVICE_ID_MIN     SXD_DEV_ID_MIN
#define SX_DEVICE_ID_MAX     SXD_DEV_ID_MAX
#define SX_DEVICE_ID_MIN_MAX SX_DEVICE_ID_MIN, SX_DEVICE_ID_MAX
#define SX_DEVICE_ID_CHECK_RANGE(device_id) (SX_CHECK_RANGE(SX_DEVICE_ID_MIN, device_id, SX_DEVICE_ID_MAX))

#define FOREACH_CHIP_TYPE(F)                                                          \
    F(SX_CHIP_TYPE_UNKNOWN = SXD_CHIP_TYPE_UNKNOWN, "CHIP_TYPE_UNKNOWN")              \
    F(SX_CHIP_TYPE_SWITCHX = SXD_CHIP_TYPE_SWITCHX_A2, "CHIP_TYPE_SWITCHX_A2")        \
    F(SX_CHIP_TYPE_SWITCHX_A2 = SXD_CHIP_TYPE_SWITCHX_A2, "Unknown chip type")        \
    F(SX_CHIP_TYPE_SWITCHX_A1 = SXD_CHIP_TYPE_SWITCHX_A1, "CHIP_TYPE_SWITCHX_A1")     \
    F(SX_CHIP_TYPE_SWITCHX_A0 = SXD_CHIP_TYPE_SWITCHX_A0, "CHIP_TYPE_SWITCHX_A0")     \
    F(SX_CHIP_TYPE_SWITCH_IB = SXD_CHIP_TYPE_SWITCH_IB, "CHIP_TYPE_SWITCH_IB")        \
    F(SX_CHIP_TYPE_SPECTRUM = SXD_CHIP_TYPE_SPECTRUM, "CHIP_TYPE_SPECTRUM")           \
    F(SX_CHIP_TYPE_SWITCH_IB2 = SXD_CHIP_TYPE_SWITCH_IB2, "CHIP_TYPE_SWITCH_IB2")     \
    F(SX_CHIP_TYPE_SPECTRUM_A1 = SXD_CHIP_TYPE_SPECTRUM_A1, "CHIP_TYPE_SPECTRUM_A1")  \
    F(SX_CHIP_TYPE_SPECTRUM2 = SXD_CHIP_TYPE_SPECTRUM2, "CHIP_TYPE_SWITCH_SPECTRUM2") \
    F(SX_CHIP_TYPE_QUANTUM = SXD_CHIP_TYPE_QUANTUM, "CHIP_TYPE_SWITCH_QUANTUM")       \
    F(SX_CHIP_TYPES_MIN = SX_CHIP_TYPE_UNKNOWN, "")                                   \
    F(SX_CHIP_TYPES_MAX = SXD_CHIP_TYPES_MAX, "")


typedef enum sx_chip_types {
    FOREACH_CHIP_TYPE(SX_GENERATE_ENUM)
} sx_chip_types_t;


#define FOREACH_CHIP_REV(F)                      \
    F(SX_CHIP_REV_UNKNOWN = 0, "Unknown")        \
    F(SX_CHIP_REV_A0 = 1 << 1, "CHIP_REV_SX_A0") \
    F(SX_CHIP_REV_A1 = 1 << 2, "CHIP_REV_SX_A1") \
    F(SX_CHIP_REV_A2 = 1 << 3, "CHIP_REV_SX_A2")

typedef enum sx_chip_rev {
    FOREACH_CHIP_REV(SX_GENERATE_ENUM)
} sx_chip_rev_t;

typedef struct {
    sx_chip_types_t type;
    sx_chip_rev_t   rev;
} sdk_chip_ver_t;

#define FOREACH_DEV_NODE_TYPE(F)                       \
    F(SX_DEV_NODE_TYPE_ALL = 0, "ALL")                 \
    F(SX_DEV_NODE_TYPE_LEAF_LOCAL, "LEAF_LOCAL")       \
    F(SX_DEV_NODE_TYPE_SPINE_LOCAL, "SPINE_LOCAL")     \
    F(SX_DEV_NODE_TYPE_LEAF, "LEAF")                   \
    F(SX_DEV_NODE_TYPE_SPINE, "SPINE")                 \
    F(SX_DEV_NODE_TYPE_HYBRID, "HYBRID")               \
    F(SX_DEV_NODE_TYPE_MIN = SX_DEV_NODE_TYPE_ALL, "") \
    F(SX_DEV_NODE_TYPE_MAX = SX_DEV_NODE_TYPE_HYBRID, "")

/**
 * sx_dev_node_type_t
 * Enumerated type - Used to note the device topology type.
 */
typedef enum sx_dev_node_type {
    FOREACH_DEV_NODE_TYPE(SX_GENERATE_ENUM)
} sx_dev_node_type_t;

#define SX_DEV_NODE_TYPE_DEFAULT SX_DEV_NODE_TYPE_LEAF
#define SX_DEV_NODE_TYPE_MIN_MAX SX_DEV_NODE_TYPE_MIN, SX_DEV_NODE_TYPE_MAX
#define SX_DEV_NODE_TYPE_CHECK_RANGE(node) (SX_CHECK_RANGE(SX_DEV_NODE_TYPE_MIN, (int)node, SX_DEV_NODE_TYPE_MAX))

/**
 * sx_dev_info_t structure is used to contain the device information.
 */
typedef struct sx_dev_info {
    sx_dev_id_t        dev_id;      /* key       */
    sx_dev_node_type_t node_type;       /* value */
    uint32_t           num_ports;   /* value */
    sx_chip_types_t    dev_type; /* value */
} sx_dev_info_t;

typedef sx_dev_info_t sx_device_info_t;

/************************************************
 *  Macro definitions
 ***********************************************/

/**
 * SX Device ID maximum/minimum values
 */
#define SX_DEV_ID_MIN        SXD_DEV_ID_MIN
#define SX_DEV_ID_MAX        SXD_DEV_ID_MAX
#define SX_DEVICE_ID_COUNT   SXD_DEV_ID_COUNT
#define SX_DEV_ID_DEFAULT    (0)
#define SX_DEVICE_ID_DEFAULT SX_DEV_ID_DEFAULT


#define SX_DEV_NUM_MAX (SX_DEV_ID_MAX + 1)

/**
 * SX Device number of Ports maximum/minimum values
 */
#define SX_DEV_PORTS_NUM_MIN 32
#define SX_DEV_PORTS_NUM_MAX (RM_API_HOST_IFC_NUM_MAX)

#define SX_DEV_ID_CHECK_RANGE(DEV_ID) SX_CHECK_RANGE(SX_DEV_ID_MIN, DEV_ID, SX_DEV_ID_MAX)

#endif /* __SX_DEV_H__ */
