/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_SWID_H__
#define __SX_SWID_H__

#include <sx/sxd/sxd_swid.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sdk/sx_check.h>


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * Switch ID.
 */
typedef sxd_swid_t sx_swid_t;
typedef sx_swid_t sx_swid_id_t;


#define MAX_NUM_OF_SWIDS 8

/**
 * SWID Type
 */
typedef enum    ku_swid_type sx_swid_type_t;

#define SX_SWID_TYPE_DISABLED   KU_SWID_TYPE_DISABLED
#define SX_SWID_TYPE_INFINIBAND KU_SWID_TYPE_INFINIBAND
#define SX_SWID_TYPE_ETHERNET   KU_SWID_TYPE_ETHERNET

/**
 * Default SWID
 */
#define SX_SWID_ID_DONTCARE (253)
#define SX_SWID_ID_STACKING (254)
#define SX_SWID_ID_DISABLED (255)
#define SX_SWID_DEFAULT     SX_SWID_ID_DISABLED
#define SX_SWID_ID_DEFAULT  SX_SWID_DEFAULT
#define SX_SWID_ID_RP       (1)

/**
 * SX SWID maximum/minimum values
 */
#define SX_SWID_ID_MIN     SXD_SWID_ID_MIN
#define SX_SWID_ID_MAX     SXD_SWID_ID_MAX
#define SX_SWID_ID_COUNT   SXD_SWID_ID_COUNT
#define SX_SWID_ID_MIN_MAX SXD_SWID_ID_MIN, SXD_SWID_ID_MAX
#define SX_SWID_CHECK_RANGE(swid_id) (SX_CHECK_MAX(swid_id, SX_SWID_ID_MAX) || SX_SWID_ID_STACKING == swid_id)

#define __ADD_STACKING_SWID_TO_DATABASE__
#ifndef     __ADD_STACKING_SWID_TO_DATABASE__
#define SX_SWID_ID_CHECK_RANGE(swid_id) SX_CHECK_MAX(swid_id, SX_SWID_ID_MAX)
#else   /*      __ADD_STACKING_SWID_TO_DATABASE__       */
#define SX_SWID_ID_CHECK_RANGE(swid_id) ((SX_SWID_ID_STACKING == swid_id) || SX_CHECK_MAX(swid_id, SX_SWID_ID_MAX))
#endif  /*      __ADD_STACKING_SWID_TO_DATABASE__       */

#define FOREACH_SWID_INFO_FIELD_BIT(F)                                        \
    F(SX_SWID_INFO_FIELD_BIT_NONE = 0, "None")                                \
    F(SX_SWID_INFO_FIELD_BIT_ID = (0x1 << 0), "ID")                           \
    F(SX_SWID_INFO_FIELD_BIT_LEARNING = (0x1 << 1), "Learning")               \
    F(SX_SWID_INFO_FIELD_BIT_INVALID = 3, "N/A")                              \
    F(SX_SWID_INFO_FIELD_BIT_HOST_TRAP_GROUP = (0x1 << 2), "Host Trap Group") \
    F(SX_SWID_INFO_FIELD_BIT_MIN = SX_SWID_INFO_FIELD_BIT_ID, "")             \
    F(SX_SWID_INFO_FIELD_BIT_MAX = SX_SWID_INFO_FIELD_BIT_HOST_TRAP_GROUP, "")

typedef enum sx_swid_info_field_bit {
    FOREACH_SWID_INFO_FIELD_BIT(SX_GENERATE_ENUM)
} sx_swid_info_field_bit_t;

#define SX_SWID_INFO_FIELD_BIT_DEFAULT SX_SWID_INFO_FIELD_BIT_NONE
#define SX_SWID_INFO_FIELD_BIT_MIN_MAX SX_SWID_INFO_FIELD_BIT_MIN, SX_SWID_INFO_FIELD_BIT_MAX
#define SX_SWID_INFO_FIELD_BIT_CHECK_RANGE(bit) \
    SX_CHECK_RANGE(SX_SWID_INFO_FIELD_BIT_MIN,  \
                   bit,                         \
                   SX_SWID_INFO_FIELD_BIT_MAX)

typedef struct sx_swid_info {
    uint32_t  fields;
    sx_swid_t id;
} sx_swid_info_t;

#endif /* __SX_SWID_H__ */
